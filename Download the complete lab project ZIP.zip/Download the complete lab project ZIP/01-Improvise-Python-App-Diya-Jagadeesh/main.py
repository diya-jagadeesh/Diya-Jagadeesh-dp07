"""FastAPI application for the GitHub Copilot TDLC lab."""

import hashlib
import secrets
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field

app = FastAPI(
    title="Text Token and Checksum API",
    description="Accept text and return a SHA-256 checksum and pseudo-random tokens.",
    version="1.0.0",
)

BASE_DIR = Path(__file__).resolve().parent
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


class TextRequest(BaseModel):
    """JSON request body for the /generate endpoint."""
    text: str = Field(..., min_length=1, max_length=5000, description="Text to process")


class TextResponse(BaseModel):
    """Structured response for processed text."""
    message: str
    text: str
    checksum: str
    tokens: list[str]


def generate(text: str) -> list[str]:
    """Generate pseudo-random tokens for the words in the supplied text."""
    words = text.split()
    if not words:
        return [secrets.token_urlsafe(8)]
    return [f"{word.lower()}-{secrets.token_hex(4)}" for word in words]


def generate_checksum(text: str) -> str:
    """Return a SHA-256 checksum of the supplied text."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


@app.get("/", response_class=HTMLResponse, tags=["Web Interface"])
async def home(request: Request):
    """Display the interactive HTML form."""
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"participant_name": "Aditya Kumar"},
    )


@app.get("/welcome", tags=["General"])
async def welcome():
    """Return a customized welcome message."""
    return {"message": "Welcome Aditya Kumar! Use this application to generate tokens and checksums."}


@app.get("/token", tags=["Token Generation"])
async def create_token():
    """Generate one secure pseudo-random token."""
    return {"token": secrets.token_urlsafe(16), "reason": "Pseudo-random identifier generated successfully"}


@app.post("/generate", response_model=TextResponse, tags=["Checksum and Token Generation"])
async def process_text(payload: TextRequest):
    """Accept JSON containing text and return its checksum and generated tokens."""
    return TextResponse(
        message="Welcome Aditya Kumar! Your text was processed successfully.",
        text=payload.text,
        checksum=generate_checksum(payload.text),
        tokens=generate(payload.text),
    )


@app.get("/health", tags=["General"])
async def health_check():
    """Return the current health status."""
    return {"status": "healthy"}
