"""Automated tests for the FastAPI application."""
import hashlib
from fastapi.testclient import TestClient
from main import app

client = TestClient(app)


def test_home_page():
    response = client.get("/")
    assert response.status_code == 200
    assert "Token and Checksum Generator" in response.text
    assert "Aditya Kumar" in response.text


def test_welcome_endpoint():
    response = client.get("/welcome")
    assert response.status_code == 200
    assert "Aditya Kumar" in response.json()["message"]


def test_generate_endpoint():
    text = "GitHub Copilot"
    expected = hashlib.sha256(text.encode("utf-8")).hexdigest()
    response = client.post("/generate", json={"text": text})
    data = response.json()
    assert response.status_code == 200
    assert data["text"] == text
    assert data["checksum"] == expected
    assert len(data["tokens"]) == 2


def test_missing_text():
    assert client.post("/generate", json={}).status_code == 422


def test_empty_text():
    assert client.post("/generate", json={"text": ""}).status_code == 422


def test_token_endpoint():
    response = client.get("/token")
    assert response.status_code == 200
    assert response.json()["token"]


def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "healthy"}
