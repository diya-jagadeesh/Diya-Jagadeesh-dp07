# Improvise Python App Using GitHub Copilot

Participant: Aditya Kumar

## Setup

Windows PowerShell:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pytest -v
python -m uvicorn main:app --reload
```

Open:
- App: http://127.0.0.1:8000
- Swagger: http://127.0.0.1:8000/docs
- ReDoc: http://127.0.0.1:8000/redoc

Test `POST /generate` with:

```json
{"text":"Testing the GitHub Copilot lab"}
```

Expected test result: 7 passed.
